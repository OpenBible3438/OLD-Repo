package gmail.zzagsk.a201501976_pyunsungkyong;

public class Note {
    String contents;
    String condition;
    String createDateStr;

    public Note(String contents, String condition, String createDateStr) {
        this.contents = contents;
        this.condition = condition;
        this.createDateStr = createDateStr;
    }

    public String getContents() {
        return contents;
    }

    public void setContents(String contents) {
        this.contents = contents;
    }

    public String getCondition() {
        return condition;
    }

    public void setCondition(String condition) {
        this.condition = condition;
    }

    public String getCreateDateStr() {
        return createDateStr;
    }

    public void setCreateDateStr(String createDateStr) {
        this.createDateStr = createDateStr;
    }
}
