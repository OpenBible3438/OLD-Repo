package gmail.zzagsk.a201501976_pyunsungkyong;

public interface OnTabItemSelectedListener {
    public void onTabSelected(int position);
}
