package gmail.zzagsk.a201501976_pyunsungkyong;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

public class Fragment3 extends Fragment {

    TextView glassTextView;
    ImageView gumjuImageView;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.fragment3, container, false);

        initUI(rootView);
        return rootView;
    }

    private void initUI(ViewGroup rootView) {

    }
}
